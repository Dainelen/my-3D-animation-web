# My 3D Site

An interactive 3D landing page built with React, Three.js, and @react-three/fiber.

## Setup

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Deploy

Push to `main` and GitHub Actions will build & deploy to Pages.
