import React from 'react'

export default function Home() {
  return (
    <section>
      <h2 className="text-2xl font-bold">Welcome</h2>
      <p className="mt-2 opacity-80">This demo uses react-three-fiber for interactive 3D scenes.</p>
    </section>
  )
}