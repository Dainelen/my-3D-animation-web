import React from 'react'

export default function Scenes() {
  return (
    <section>
      <h2 className="text-2xl font-bold">Scenes</h2>
      <p className="mt-2 opacity-80">Add extra scenes in <code>src/components</code> and route here.</p>
    </section>
  )
}