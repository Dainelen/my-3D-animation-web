import React from 'react'

export default function About() {
  return (
    <section>
      <h2 className="text-2xl font-bold">About</h2>
      <p className="mt-2 opacity-80">A simple portfolio showcasing 3D work built with React + r3f.</p>
    </section>
  )
}