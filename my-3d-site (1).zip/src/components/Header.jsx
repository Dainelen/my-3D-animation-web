import React from 'react'

export default function Header() {
  return (
    <header className="max-w-6xl mx-auto p-6 flex items-center justify-between">
      <div className="text-xl font-semibold">My 3D Site</div>
      <nav className="flex gap-4">
        <a href="#home" className="text-sm">Home</a>
        <a href="#scenes" className="text-sm">Scenes</a>
        <a href="#about" className="text-sm">About</a>
      </nav>
    </header>
  )
}